# Ma Sói Quản Trò – Android (Capacitor)

App HTML gốc đã được đóng gói thành project Android bằng Capacitor 8.

- **App ID:** `com.datld.masoi` · **Tên app:** Ma Sói Quản Trò
- Web app: `www/index.html` (đã vá xử lý nút Back Android)
- Project Android: `android/` (đã bật giữ màn hình luôn sáng)

## Lấy file APK — chọn 1 trong 2 cách

### Cách A: Build trên cloud bằng GitHub (không cần cài gì trên máy)

Đã có sẵn workflow `.github/workflows/build-apk.yml`.

1. Tạo tài khoản GitHub miễn phí: https://github.com/signup
2. Tạo repository mới (chọn Private cũng được)
3. Đưa code lên — cách dễ nhất là cài GitHub Desktop (https://desktop.github.com):
   **Add local repository** → chọn thư mục `masoi-android` → Commit → Publish
4. Vào repo trên web → tab **Actions** → workflow "Build APK" tự chạy (~3-5 phút)
5. Bấm vào lần chạy → mục **Artifacts** → tải **MaSoi-QuanTro-APK** (file zip chứa `app-debug.apk`)
6. Chép APK vào điện thoại và cài (bật "Cài từ nguồn không xác định")

### Cách B: Build trên máy bằng Android Studio

1. Cài **Android Studio**: https://developer.android.com/studio
2. **Open** → chọn thư mục `masoi-android/android`, đợi Gradle sync (lần đầu vài phút)
3. **Build → Generate App Bundles or APKs → Generate APKs**
4. APK ở `android/app/build/outputs/apk/debug/app-debug.apk`

## Khi sửa game (file HTML)

1. Sửa `www/index.html`
2. Cách A: chỉ cần commit + push lại, APK mới tự build.
   Cách B: cài Node.js rồi chạy `npx cap sync android` trong thư mục `masoi-android`, build lại.

## Đưa lên Google Play (tuỳ chọn)

- Tài khoản Google Play Developer: $25 một lần
- Build bản release có ký: Android Studio → **Build → Generate Signed App Bundle** (tạo keystore, GIỮ KỸ file này)
- Upload file `.aab` lên Play Console

## Đổi icon app

Android Studio: chuột phải `res` → **New → Image Asset**, hoặc thay file trong `android/app/src/main/res/mipmap-*/`.
